<div align="center">
	<a href="http://joomlacode.org/gf/project/noixacl" target="_blank"><img border="0" src="<?php echo "components/com_noixacl/images/noixacl.gif"; ?>" /></a>
	<br />
	<?php echo JText::_("Version 2.0.6 Beta"); ?>
</div>
